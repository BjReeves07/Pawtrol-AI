package com.pawtrolai.pawtrol_ai_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PawtrolAiBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PawtrolAiBackendApplication.class, args);
	}

}
