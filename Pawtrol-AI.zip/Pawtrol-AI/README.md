# Pawtrol-AI
Pawtrol AI is an Intelligent animal monitoring system that is designed to assist pet owners and animal shelters in tracking and understanding animal behavior. Pawtrol AI combines many technologies such as Machine learning, Large language models, and computer vision. Pawltrol reports animal behavior and actions based on inputed recurring snapshots.
