package com.pawtrolai.pawtrol_ai_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PawtrolAiBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
